import logging
import tornado.escape
import tornado.ioloop
import tornado.web
import os.path
import uuid
import json

import datetime
from datetime import timedelta

# import redis
import pymongo
from pymongo import MongoClient
from bson.objectid import ObjectId

from tornado.concurrent import Future
from tornado import gen
from tornado.options import define, options, parse_command_line

define("port", default=8080, help="run on the given port", type=int)
define("debug", default=False, help="run in debug mode")


"""
Instantiating MongoDB client

Using Mongo defaults, without security or any configurations, for demo purposes

"""

mongo = MongoClient()
db = mongo['mini_notifs']
notifications_collection = db.notifications
users_collection = db.users


class Notifications(object):
    def __init__(self):
        # Maintain list of current clients
        self.connected = {}

    def wait_for_notifications(self, key=None):
        result_future = Future()
        self.connected[key] = result_future
        return result_future


notifs = Notifications()

class BaseHandler(tornado.web.RequestHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header('Access-Control-Allow-Methods', ' PUT, DELETE, OPTIONS')
        self.set_header("Access-Control-Allow-Credentials", "true")
        self.set_header("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers")

    def options(self):
        # no body
        self.set_status(204)
        self.finish()


class MessageUpdatesHandler(BaseHandler):
    @gen.coroutine
    def get(self):
        self.key = self.get_argument("key", None)
        print("GET says key is "+format(self.key))

        self.future = Future()
        self.get_user_notifications(key=self.key, future=self.future)

        notifications = yield self.future


        # self.get_user_notifications(key=self.key)

        if self.request.connection.stream.closed():
            return
        self.write(json.dumps(dict(notification=notifications)))

    # def wait_for_notifications(key):
    #     result_future = Future()
    #     self.connected[key] = result_future
    #     return result_future

    def get_user_notifications(self, key=None, future=None):
        if key:
            user = users_collection.find_one({"current_key": key})
            user_notifications = notifications_collection.find({"to_user_id": user["_id"], "is_fresh": True})

            for notif in user_notifications:
                n = {}

                n["user_detail"] = users_collection.find_one({"_id": notif["from_user_id"]})
                n['post_id'] = str(notif['post_id'])

                n['html'] = tornado.escape.to_basestring(self.render_string("notification.html", notif=n))
                print(format(n))

                # self.write(n)

                # notifs.new_notifs([n], key=key)
                print("Sending notif")
                # self.write(dict(notification=n['html']))
                future.set_result(n['html'])

            notifications_collection.update({"to_user_id": user['_id'], "is_fresh": True}, {"$set": {"is_fresh": False}}, upsert=False, multi=True)
        else:
            print("Without key")

    def post(self):
        self.key = self.get_argument("key", None)
        print("POST says key is "+format(self.key))

    # def on_connection_close(self):
        # notifs.cancel_wait(self.future, self.key)


def main():
    parse_command_line()
    app = tornado.web.Application(
        [
            (r"/mini_notif_server", MessageUpdatesHandler),
            ],
        cookie_secret="PO_there_are_no_secrets",
        template_path=os.path.join(os.path.dirname(__file__), "templates"),
        static_path=os.path.join(os.path.dirname(__file__), "static"),
        xsrf_cookies=False,
        debug=options.debug,
        )
    app.listen(options.port)
    tornado.ioloop.IOLoop.current().start()


if __name__ == "__main__":
    main()